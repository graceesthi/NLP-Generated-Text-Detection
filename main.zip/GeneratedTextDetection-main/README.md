This work is licensed under the Creative Commons Attribution 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

# GeneratedTextDetection
If you use the code repository or the dataset, please cite the paper:
"A Benchmark Corpus for the Detection of Automatically Generated Text in Academic Publications"

